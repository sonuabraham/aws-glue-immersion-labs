# lab3 example placeholder
print('Running lab3')
