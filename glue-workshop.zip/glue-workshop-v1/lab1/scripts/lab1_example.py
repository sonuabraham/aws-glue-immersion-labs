# lab1 example placeholder
print('Running lab1')
