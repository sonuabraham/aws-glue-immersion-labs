# lab1

Contents for lab1 - reconstructed for AWS Glue Immersion Day.
