# lab5 example placeholder
print('Running lab5')
