# lab2 example placeholder
print('Running lab2')
