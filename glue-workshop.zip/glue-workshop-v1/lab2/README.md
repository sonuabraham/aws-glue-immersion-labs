# lab2

Contents for lab2 - reconstructed for AWS Glue Immersion Day.
