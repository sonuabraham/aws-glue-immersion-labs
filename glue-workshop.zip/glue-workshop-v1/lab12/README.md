# lab12

Contents for lab12 - reconstructed for AWS Glue Immersion Day.
