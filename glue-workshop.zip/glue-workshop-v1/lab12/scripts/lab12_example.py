# lab12 example placeholder
print('Running lab12')
