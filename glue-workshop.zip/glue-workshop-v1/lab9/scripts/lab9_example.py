# lab9 example placeholder
print('Running lab9')
