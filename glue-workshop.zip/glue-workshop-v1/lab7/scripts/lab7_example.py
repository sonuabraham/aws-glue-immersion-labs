# lab7 example placeholder
print('Running lab7')
