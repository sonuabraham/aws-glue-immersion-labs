# lab8 example placeholder
print('Running lab8')
