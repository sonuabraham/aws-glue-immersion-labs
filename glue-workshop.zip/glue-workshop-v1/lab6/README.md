# lab6

Contents for lab6 - reconstructed for AWS Glue Immersion Day.
