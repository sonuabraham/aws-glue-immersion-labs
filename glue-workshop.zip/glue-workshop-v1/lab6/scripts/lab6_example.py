# lab6 example placeholder
print('Running lab6')
