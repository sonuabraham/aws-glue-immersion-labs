#!/bin/bash
echo 'Setup environment'
