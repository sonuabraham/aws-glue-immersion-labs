# lab10 example placeholder
print('Running lab10')
